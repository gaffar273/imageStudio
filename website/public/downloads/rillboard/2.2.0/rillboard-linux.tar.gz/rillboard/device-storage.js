(() => {
  'use strict';
  // Native writes complete on disk before callers report a successful save.
  // Migrate each old value on first read, retaining the browser copy for recovery.
  const native = window.chrome?.webview?.hostObjects?.sync?.drawingStorage;
  if (!native) { window.DrawingStorage = localStorage; return; }
  // Native boards, undo entries and history can share one immutable image.
  // Write the bytes before publishing any durable record that references them.
  const bySource=new Map(), byId=new Map();
  const assetKey=id=>'local-excalidraw-workspace-v1:image:'+id;
  function remember(id,src,saved){
    const asset={id,src,saved};
    bySource.set(src,asset);
    byId.set(id,asset);
    return asset;
  }
  const images={
    compact(elements,persist){
      return elements.map(el=>{
        if(el.type!=='image'||!el.src)return el;
        const {src,...metadata}=el;
        const asset=bySource.get(src)||remember(crypto.randomUUID(),src,false);
        if(persist && !asset.saved){
          native.Write(assetKey(asset.id),src);
          asset.saved=true;
        }
        return {...metadata,imageRef:asset.id};
      });
    },
    expand(elements){
      return elements.map(el=>{
        if(el?.type!=='image'||!el.imageRef||el.src)return el;
        const {imageRef,...metadata}=el;
        if(!/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(imageRef))throw Error('Invalid saved image reference.');
        let asset=byId.get(imageRef);
        if(!asset){
          const src=native.Read(assetKey(imageRef));
          if(!src)throw Error('A saved board image could not be read.');
          asset=remember(imageRef,src,true);
        }
        return {...metadata,src:asset.src};
      });
    },
    keepScene(elements){
      // Board switches clear undo/redo. Release image strings from those stacks too.
      const used=new Set(elements.filter(el=>el.type==='image').map(el=>el.src));
      for(const [src] of bySource)if(!used.has(src))bySource.delete(src);
      for(const [id,asset] of byId)if(!used.has(asset.src))byId.delete(id);
    }
  };
  window.DrawingStorage = {
    images,
    separateHistory: true,
    getItem(key) {
      const saved = native.Read(key);
      if (saved !== null && saved !== undefined) return saved;
      const legacy = localStorage.getItem(key);
      if (legacy !== null) native.Write(key, legacy);
      return legacy;
    },
    setItem(key, value) { native.Write(key, String(value)); }
  };
})();
