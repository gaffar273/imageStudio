(() => {
  'use strict';
  const $=selector=>document.querySelector(selector);
  const panel=$('#symbolic-panel'), field=$('#symbolic-input'), output=$('#symbolic-output');
  const operation=$('#symbolic-op'), status=$('#symbolic-status');
  const examples={
    simplify:'\\frac{x^2-1}{x-1}',factor:'x^4-1',expand:'(x+1)^4',
    diff:'x^2y+\\sin(x)',integrate:'x\\cos(x)',defint:'x^2',limit:'\\frac{\\sin(x)}{x}',
    solve:'x^2-5x+6=0',sum:'k^2',product:'k',
    determinant:'\\begin{bmatrix}1&2\\\\3&4\\end{bmatrix}',invert:'\\begin{bmatrix}1&2\\\\3&4\\end{bmatrix}'
  };
  let worker,timer,workerUrl;
  function stop() {
    clearTimeout(timer);
    if(worker){worker.terminate();worker=null;}
    $('#symbolic-run').disabled=false;
  }
  function invalidate() {
    stop();
    output.hidden=true;
    $('#symbolic-result-actions').hidden=true;
    status.textContent='Enter an expression and choose Calculate.';
  }
  function switchView(symbolic) {
    panel.hidden=!symbolic;
    $('.graph-studio-layout').hidden=symbolic;
    $('.graph-footer').hidden=symbolic;
    $('#graph-tab').setAttribute('aria-pressed',String(!symbolic));
    $('#symbolic-tab').setAttribute('aria-pressed',String(symbolic));
    window.mathVirtualKeyboard.hide();
    if(symbolic){
      field.mathVirtualKeyboardPolicy='manual';
      field.smartSuperscript=false;
      field.inlineShortcuts={...field.inlineShortcuts,int:'\\int_{#?}^{#?}#?\\,\\mathrm{d}x',
        sum:'\\sum_{k=#?}^{#?}\\left(#?\\right)',prod:'\\prod_{k=#?}^{#?}\\left(#?\\right)',
        lim:'\\lim_{x\\to#?}\\left(#?\\right)'};
      if(!field.value)field.value=examples.simplify;
      field.focus();
    }else{
      window.dispatchEvent(new Event('resize'));
      $('#graph-rows math-field')?.focus();
    }
  }
  function fields() {
    const op=operation.value;
    $('#symbolic-variable-field').hidden=!['diff','integrate','defint','limit','solve','sum','product'].includes(op);
    $('#symbolic-from-field').hidden=!['limit','defint','sum','product'].includes(op);
    $('#symbolic-from-field span').textContent=op==='limit'?'Approaches':'From';
    $('#symbolic-to-field').hidden=!['defint','sum','product'].includes(op);
  }
  function example() {
    invalidate();
    field.value=examples[operation.value];
    $('#symbolic-variable').value=['sum','product'].includes(operation.value)?'k':'x';
    $('#symbolic-from').value=['sum','product'].includes(operation.value)?'1':'0';
    $('#symbolic-to').value=['sum','product'].includes(operation.value)?'10':'1';
  }
  // Each calculation runs in an interruptible worker, including in file-based installations.
  function workerMain(){
    self.onmessage=({data})=>{
      try{
        const {op,expression,variable,from,to}=data;
        const argument=value=>{
          if(!/^[a-z0-9π.+*/^() -]{1,48}$/i.test(value))throw Error('Enter a number or a constant for the bound.');
          const bound=nerdamer(value.replace(/π/g,'pi').replace(/^(-?)inf(inity)?$/i,'$1Infinity'));
          if(bound.variables().length)throw Error('Enter a numeric bound or infinity.');
          return bound.toString();
        };
        let args=[expression];
        if(['diff','integrate','limit','solve'].includes(op))args.push(variable);
        if(op==='limit')args.push(argument(from));
        if(op==='defint')args.push(argument(from),argument(to),variable);
        if(op==='sum'||op==='product')args.push(variable,argument(from),argument(to));
        const answer=nerdamer(op+'('+args.join(',')+')');
        const latex=answer.toTeX(),text=answer.toString();
        if(latex.length>10000)throw Error('This result is too long to display.');
        self.postMessage({latex,text,variables:answer.variables()});
      }catch(error){self.postMessage({error:error.message});}
    };
  }
  function calculate() {
    invalidate();
    try{
      const variable=$('#symbolic-variable').value.trim();
      if(!$('#symbolic-variable-field').hidden && !/^[a-zA-Z]$/.test(variable))throw Error('Choose a single letter for the variable.');
      const expression=window.GraphMath.read(field.value,false,true);
      if(!expression)throw Error('Enter an expression.');
      if(!workerUrl)workerUrl=URL.createObjectURL(new Blob([window.RillboardCASSource,'\n;(',workerMain.toString(),')();'],{type:'text/javascript'}));
      worker=new Worker(workerUrl);
      $('#symbolic-run').disabled=true;
      status.textContent='Calculating…';
      timer=setTimeout(()=>{stop();status.textContent='Calculation timed out. Try simplifying the expression or reducing the bounds.';},6000);
      worker.onerror=()=>{stop();status.textContent='The symbolic engine could not complete this calculation.';};
      worker.onmessage=({data})=>{
        stop();
        if(data.error){status.textContent=data.error;return;}
        output.value=data.latex.replace(/vmatrix/g,'bmatrix').replace(/\\cr\b/g,'\\\\')+(operation.value==='integrate'?'+C':'');
        output.hidden=false;
        status.textContent=operation.value==='solve'?'Check solution candidates against the original domain.':'';
        $('#symbolic-result-actions').hidden=false;
        const plot=$('#symbolic-plot');
        plot.hidden=true;
        plot.textContent=operation.value==='integrate'?'Plot with C = 0':'Plot result';
        if(data.variables.every(v=>v==='x') && !data.text.includes('[')){
          try{window.Board.equation(window.GraphMath.read(data.latex));plot.hidden=false;}catch{}
        }
        plot.dataset.latex=data.latex;
      };
      worker.postMessage({op:operation.value,expression,variable,from:$('#symbolic-from').value,to:$('#symbolic-to').value});
    }catch(error){stop();status.textContent=error.message;}
  }
  $('#graph-tab').addEventListener('click',()=>switchView(false));
  $('#symbolic-tab').addEventListener('click',()=>switchView(true));
  $('#graph-dialog').addEventListener('close',()=>{stop();if(!panel.hidden)switchView(false);});
  $('#symbolic-run').addEventListener('click',calculate);
  panel.addEventListener('input',invalidate);
  operation.addEventListener('change',()=>{invalidate();fields();});
  $('#symbolic-example').addEventListener('click',example);
  $('#symbolic-plot').addEventListener('click',event=>{
    switchView(false);
    document.dispatchEvent(new CustomEvent('graph-result',{detail:event.currentTarget.dataset.latex}));
  });
  $('#symbolic-copy').addEventListener('click',async()=>{
    try{await navigator.clipboard.writeText(output.value);status.textContent='LaTeX copied.';}
    catch{output.focus();output.select();status.textContent='Press Ctrl+C to copy the selected result.';}
  });
  panel.addEventListener('keydown',event=>{
    if(event.key==='Enter' && (event.ctrlKey||event.metaKey)){event.preventDefault();calculate();}
  });
  fields();
})();
