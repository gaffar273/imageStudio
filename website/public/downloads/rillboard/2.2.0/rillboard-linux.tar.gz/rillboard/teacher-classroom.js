(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./geometry.js'));
  else root.TeacherClassroom = factory(root.Board);
})(globalThis, function (B) {
  'use strict';

  function summary(element) {
    const {id, type, x, y, w, h, text} = element;
    return {id, type, x, y, w, h, text: text?.slice(0, 320)};
  }

  function intersects(a, b) {
    return a.x <= b.x+b.w && b.x <= a.x+a.w && a.y <= b.y+b.h && b.y <= a.y+a.h;
  }

  // Freeze the student's reference when they submit. Subsequent edits and replay
  // must never change which marks the teacher is answering.
  function reference(elements, ids, point) {
    const selected = elements.filter(e => ids.has(e.id));
    const bounds = point ? {x:point.x-12,y:point.y-12,w:24,h:24} : B.union(selected);
    if (!bounds) return {};
    const pad=point?80:40;
    const region = {x:bounds.x-pad, y:bounds.y-pad, w:bounds.w+2*pad, h:bounds.h+2*pad};
    const nearby = elements.filter(e => intersects(region, B.bounds(e)));
    const labels = nearby.filter(e => e.type === 'text' && !ids.has(e.id));
    return {
      bounds, point, selected: selected.slice(0, 6).map(summary), count: selected.length,
      labels: labels.slice(0, 4).map(summary), region,
      visual: nearby.some(e => ['pencil','image'].includes(e.type))
    };
  }

  async function crop(elements, background, region, point) {
    const scale = Math.min(2, 640 / region.w, 480 / region.h);
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.ceil(region.w * scale));
    canvas.height = Math.max(1, Math.ceil(region.h * scale));
    const visible = elements.filter(e => intersects(region, B.bounds(e)));
    const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="'+canvas.width+'" height="'+canvas.height+'" viewBox="'+
      [region.x,region.y,region.w,region.h].join(' ')+'">'+visible.map(e => B.elementSvg(B.visibleElement(e,background))).join('')+'</svg>';
    const url = URL.createObjectURL(new Blob([svg], {type:'image/svg+xml'}));
    try {
      const image = new Image();
      image.src = url;
      await image.decode();
      const context = canvas.getContext('2d');
      context.fillStyle = background;
      context.fillRect(0,0,canvas.width,canvas.height);
      context.drawImage(image,0,0);
      if(point){
        const x=(point.x-region.x)*canvas.width/region.w,y=(point.y-region.y)*canvas.height/region.h;
        context.beginPath();context.arc(x,y,6,0,Math.PI*2);
        context.strokeStyle='white';context.lineWidth=4;context.stroke();
        context.strokeStyle='#2454a3';context.lineWidth=2;context.stroke();
      }
      return canvas.toDataURL('image/png').split(',')[1];
    } finally { URL.revokeObjectURL(url); }
  }

  function publicTurn(turn) {
    const {id, kind, text, step, prompt, lessonContext, context, preview, answeredAt} = turn;
    return {id, kind, text, step, prompt, lessonContext, selected:context.selected, nearbyLabels:context.labels,
      selectedCount:context.count, point:context.point, hasCrop:!!preview, answeredAt};
  }

  function responseAt(responses, step) {
    const response = responses[step];
    if (!response?.submittedAt) return {};
    const {answer, submittedAt, hintUsed} = response;
    return {[step]:{answer, submittedAt, hintUsed}};
  }

  function sceneForRead(scene, turns, responses, step, options, lessonElements=scene.elements) {
    const pending = turns.filter(turn => !turn.answeredAt);
    const turn = options.turnId ? turns.find(t => t.id === options.turnId) : pending[0];
    if (options.turnId && !turn) throw Error('Question not found on this board.');
    const expanded = options.detail === 'full' || options.detail === 'compact';
    const elements = expanded ? scene.elements : turn ? [] : lessonElements.slice(-8);
    const result = {
      board: {id:scene.id, totalElements:scene.elements.length, elements:expanded ? elements : elements.map(summary)},
      responses: turn?.kind==='question'?{}:responseAt(responses,turn?.step ?? step),
      pendingCount:pending.length
    };
    if (turn) result.studentTurn = publicTurn(turn);
    if (expanded) {
      result.board = {...scene, elements:options.detail === 'full' ? elements : elements.map(e => {
        const {id,type,x,y,w,h,text} = e;
        return {id,type,x,y,w,h,text};
      })};
      delete result.board.boards;
      result.responses = Object.assign({}, ...Object.keys(responses).map(key => responseAt(responses,key)));
    }
    return result;
  }

  function placeReply(note, bounds, elements, writingWidth) {
    if (!bounds) return;
    const blocks = elements.map(B.bounds);
    const containing = blocks.filter(b=>intersects(b,bounds));
    const right = Math.max(bounds.x+bounds.w,...containing.map(b=>b.x+b.w));
    const positions = [[bounds.x+bounds.w+28,bounds.y], [bounds.x-note.w-28,bounds.y],
      [bounds.x,bounds.y+bounds.h+24],[right+36,bounds.y]];
    for (const [x,y] of positions) {
      if (x < 0 || x+note.w > writingWidth) continue;
      const area = {x:x-8,y:y-8,w:note.w+16,h:note.h+16};
      if (blocks.some(b => intersects(area,b))) continue;
      note.x=x; note.y=y;
      return;
    }
    // The default note position is below existing work on a crowded board.
  }

  return {reference, crop, publicTurn, responseAt, sceneForRead, placeReply};
});
