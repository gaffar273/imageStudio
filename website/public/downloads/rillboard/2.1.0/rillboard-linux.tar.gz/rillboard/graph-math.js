/* Convert the mathfield's notation to the board's bounded arithmetic grammar. */
(function(root, factory) {
  if(typeof module==='object' && module.exports) module.exports=factory();
  else root.GraphMath=factory();
})(globalThis, function() {
  'use strict';
  const commands={cdot:'*',times:'*',div:'/',pi:'pi',theta:'theta',le:'<=',leq:'<=',ge:'>=',geq:'>=',ne:'!=',neq:'!=',lparen:'(',rparen:')'};
  const functions=new Set('sin cos tan sec csc cot arcsin arccos arctan sinh cosh tanh ln log exp min max'.split(' '));
  const superscripts='⁰¹²³⁴⁵⁶⁷⁸⁹';
  // A typeset x followed by cos(x) denotes a product. Preserve that boundary for the CAS.
  const operators='integrate defint int limit diff sum product sqrt cbrt abs exp ln log log2 floor ceil round sign min max pow hypot if sin cos tan sec csc cot asin acos atan atan2 sinh cosh tanh asinh acosh atanh indiax indiay'.split(' ');
  const names=[...operators,'Infinity','pi','theta','alpha','beta','gamma','delta','epsilon','lambda','mu','sigma','omega','phi'].sort((a,b)=>b.length-a.length);
  const atoms=new RegExp('(?:\\d+\\.?\\d*|\\.\\d+)(?:[eE][+-]?\\d+)?|'+names.join('|')+'|.','g');
  function products(expression){
    let previous='',result='';
    for(const token of expression.match(atoms)||[]){
      const left=/^[a-zA-Z0-9.]|^[)]$/.test(previous);
      const right=/^[a-zA-Z(]/.test(token);
      if(left && right && !operators.includes(previous))result+='*';
      result+=token;
      previous=token;
    }
    return result;
  }
  function read(latex, display=false, symbolic=false) {
    if(latex.length>4000) throw Error('Shorten this expression.');
    if(symbolic){
      const matrix=/^\\begin\{((?:p|b|v)?matrix)\}([\s\S]*?)\\end\{\1\}$/.exec(latex.trim());
      if(matrix){
        const rows=matrix[2].split(/\\\\/).map(row=>row.split('&').map(cell=>read(cell,false,true)));
        if(!rows[0].length || rows.some(row=>row.length!==rows[0].length || row.some(cell=>!cell)))throw Error('Complete every matrix entry.');
        return 'matrix('+rows.map(row=>'['+row.join(',')+']').join(',')+')';
      }
    }
    const tokens=latex.match(/\\[a-zA-Z]+|\\.|[^\s]/g)||[];
    let i=0;
    function group() {
      if(i>=tokens.length || tokens[i]==='}') throw Error('Complete the expression.');
      if(tokens[i]!=='{') return part();
      i++;
      const result=sequence('}');
      if(tokens[i++]!=='}') throw Error('Complete the group.');
      return result;
    }
    function sequence(stop) {
      let value='';
      while(i<tokens.length && tokens[i]!==stop) value+=part();
      return value;
    }
    function integral() {
      const bounds={};
      while(tokens[i]==='^'||tokens[i]==='_') {
        const which=tokens[i++];
        bounds[which]=group();
      }
      if(!(symbolic && !bounds['_'] && !bounds['^']) && (!bounds['_']||!bounds['^'])) throw Error('Enter the lower and upper limits.');
      let body='';
      while(i<tokens.length && tokens[i]!=='}') {
        // MathLive accepts either a typed dx or the upright d in the integral template.
        const marker=tokens[i]==='d' && /^[a-z]$/.test(tokens[i+1]||'');
        const upright=['\\mathrm','\\operatorname'].includes(tokens[i]) && tokens.slice(i+1,i+4).join('')==='{d}';
        if(marker || upright || tokens[i]==='\\differentialD') {
          i+=upright?4:1;
          const variable=tokens[i++];
          if(!/^[a-z]$/.test(variable||'') || !body.trim()) break;
          if(symbolic)return bounds['_']?'defint('+[body,bounds['_'],bounds['^'],variable].join(',')+')':'integrate('+body+','+variable+')';
          return display?'∫['+bounds['_']+', '+bounds['^']+'] '+body+' d'+variable:'int('+[variable,bounds['_'],bounds['^'],body].join(',')+')';
        }
        body+=part();
      }
      throw Error('Finish the integral with a differential such as dt.');
    }
    function part() {
      const token=tokens[i++];
      if(token==='{') {i--;return '('+group()+')';}
      if(token==='\\left'||token==='\\mleft'){
        if(tokens[i]==='|'||tokens[i]==='\\lvert'){i++;return display?'|':'abs(';}
        return '';
      }
      if(token==='\\right'||token==='\\mright'){
        if(tokens[i]==='|'||tokens[i]==='\\rvert'){i++;return display?'|':')';}
        return '';
      }
      if(['\\,','\\!','\\;','\\:', '\\quad','\\ '].includes(token))return '';
      if(token==='\\placeholder')throw Error('Fill in the empty box.');
      if(token==='\\int')return integral();
      if(symbolic && ['\\sum','\\prod','\\lim'].includes(token)){
        const bounds={};
        while(tokens[i]==='^'||tokens[i]==='_'){
          const which=tokens[i++];
          bounds[which]=group();
        }
        const head=bounds['_']||'';
        const match=token==='\\lim'?/^([a-z])~(.+)$/.exec(head):/^([a-z])=(.+)$/.exec(head);
        if(!match || (token!=='\\lim'&&!bounds['^']))throw Error('Complete the variable and bounds.');
        const body=sequence('}');
        if(!body)throw Error('Enter the expression to calculate.');
        return token==='\\lim'?'limit('+[body,match[1],match[2]].join(',')+')':
          (token==='\\sum'?'sum':'product')+'('+[body,match[1],match[2],bounds['^']].join(',')+')';
      }
      if(symbolic && token==='\\to')return '~';
      if(symbolic && token==='\\partial')return '∂';
      if(['\\frac','\\tfrac','\\dfrac'].includes(token)){
        const n=group(),d=group();
        if(symbolic && /^(d|∂)$/.test(n) && new RegExp('^'+n+'[a-z]$').test(d)){
          const body=sequence('}');
          if(!body)throw Error('Enter the function to differentiate.');
          return 'diff('+body+','+d[1]+')';
        }
        return '(('+n+')/('+d+'))';
      }
      if(token==='\\sqrt'){
        if(tokens[i]==='['){
          i++;const degree=sequence(']');
          if(tokens[i++]!==']')throw Error('Complete the root index.');
          const body=group();
          if(degree==='3')return (display?'∛':'cbrt')+'('+body+')';
          return '(('+body+')^(1/('+degree+')))';
        }
        return (display?'√':'sqrt')+'('+group()+')';
      }
      if(token==='^'){
        const power=group();
        if(display && /^-?\d+$/.test(power))return [...power].map(c=>c==='-'?'⁻':superscripts[c]).join('');
        return '^('+power+')';
      }
      if(token==='\\log' && tokens[i]==='_'){
        i++;const base=group();
        if(base==='2')return 'log2';
        if(base==='10')return 'log';
        throw Error('Use log base 2, log base 10, or ln.');
      }
      if(token==='\\operatorname'||token==='\\mathrm'||token==='\\mathit')return group();
      if(token.startsWith('\\')){
        const name=token.slice(1);
        if(Object.hasOwn(commands,name)){
          if(display)return ({pi:'π',theta:'θ',cdot:'·',times:'×',div:'÷',le:'≤',leq:'≤',ge:'≥',geq:'≥',ne:'≠',neq:'≠'})[name]||commands[name];
          return commands[name];
        }
        if(symbolic && name==='infty')return 'Infinity';
        if(symbolic && /^(alpha|beta|gamma|delta|epsilon|lambda|mu|sigma|omega|phi)$/.test(name))return name;
        if(functions.has(name))return name.replace(/^arc/,'a');
        if(name==='%')return '%';
        throw Error('The graph cannot plot '+token+'.');
      }
      return token;
    }
    const expression=sequence();
    return display?expression:products(expression);
  }
  return {read};
});

