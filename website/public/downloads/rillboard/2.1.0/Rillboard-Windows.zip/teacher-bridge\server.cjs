'use strict';
// MCP stdio transport: one JSON-RPC message per line; stdout is protocol-only.
const readline=require('node:readline');
const {request,defaultDirectory}=require('./client.cjs');
const fs=require('node:fs/promises'),path=require('node:path');
const channel=require('node:crypto').randomUUID().replaceAll('-','');
const known=new Set(),subscriptions=new Set();
let timer,checking=false;
const uriFor=key=>'elixdraw://lesson/'+encodeURIComponent(key)+'/questions';
function origin(key,readTurn=false){return {source:'mcp',client:clientName,readTurn,channel:subscriptions.has(key)?channel:undefined};}
async function checkNotifications(){
  if(checking||!subscriptions.size)return;
  checking=true;
  const directory=process.env.TEACHER_BRIDGE_DIR||defaultDirectory();
  try{
    const files=(await fs.readdir(directory)).filter(f=>f.startsWith(channel+'.')&&f.endsWith('.turn.json'));
    if(!files.length)return;
    const descriptor=JSON.parse(await fs.readFile(path.join(directory,'session.json'),'utf8'));
    for(const file of files){
      const target=path.join(directory,file);
      const event=JSON.parse(await fs.readFile(target,'utf8'));
      if(descriptor.enabled&&event.session===descriptor.session&&subscriptions.has(event.conversationId)){
        process.stdout.write(JSON.stringify({jsonrpc:'2.0',method:'notifications/resources/updated',params:{uri:uriFor(event.conversationId)}})+'\n');
      }
      await fs.unlink(target);
    }
  }catch(error){if(error.code!=='ENOENT')process.stderr.write('Teaching notification: '+error.message+'\n');}
  finally{checking=false;}
}
let clientName='MCP client';
const object=properties=>({type:'object',properties,additionalProperties:false});
const conversationId={type:'string',pattern:'^[a-zA-Z0-9_:.\\-]{1,200}$',description:'Key returned by this chat’s first teacher_start.'};
const element={type:'object',description:'Editable drawing element. Use unique stable id. Coordinates are board units; x/y is top left. Text supports Unicode and newlines. Lines/arrows use w/h as signed endpoint offsets. Pencil points are relative [x,y] pairs.',properties:{
  id:{type:'string',pattern:'^[a-zA-Z0-9_-]{1,80}$'},type:{enum:['rectangle','diamond','ellipse','line','arrow','text','pencil','image']},
  x:{type:'number'},y:{type:'number'},w:{type:'number'},h:{type:'number'},text:{type:'string'},fontSize:{type:'number'},
  stroke:{type:'string',description:'Hex color, for example #1971c2.'},fill:{type:'string'},fillStyle:{enum:['solid','hachure']},strokeWidth:{type:'number'},rough:{type:'number'},opacity:{type:'number'},dash:{enum:['solid','dashed','dotted']},
  points:{type:'array',items:{type:'array',items:{type:'number'},minItems:2,maxItems:2}},src:{type:'string',description:'Image data URL, PNG/JPEG/WebP/GIF only.'}
},required:['id','type','x','y'],additionalProperties:false};
const step={...object({caption:{type:'string',maxLength:4000},pageBreak:{type:'boolean',description:'Continue in a fresh section BELOW all existing work; local y coordinates start on that section. Earlier pages remain on the board.'},durationMs:{type:'number',minimum:500,maximum:60000},focus:{type:'array',items:{type:'string'}},pointer:{...object({x:{type:'number'},y:{type:'number'}}),required:['x','y']},actions:{type:'array',maxItems:200,items:{oneOf:[
  {...object({op:{const:'add'},element}),required:['op','element']},
  {...object({op:{const:'update'},id:{type:'string'},changes:{type:'object',description:'Changed drawing properties; id and type remain unchanged.'}}),required:['op','id','changes']},
  {...object({op:{const:'remove'},id:{type:'string'}}),required:['op','id']}
]}}}),required:['caption','actions']};
const question={...object({prompt:{type:'string',minLength:1,maxLength:1000},hint:{type:'string',maxLength:1000}}),required:['prompt']};
step.properties.question=question;
const turnId={type:'string',maxLength:80};
const string={type:'string'},number={type:'number'};
const graph={...object({expression:{type:'string',maxLength:2000,description:'One equation per line.'},xmin:number,xmax:number,ymin:number,ymax:number,
  step:number,xLabel:string,yLabel:string,highlight:{type:'integer',minimum:0,description:'Curve index, starting at zero.'}}),required:['expression']};
const tools=[
  {name:'teacher_start',description:'Start a new chat with title and empty steps. An existing key resumes its board.',inputSchema:{
    ...object({conversationId,title:{type:'string',minLength:1,maxLength:100},steps:{type:'array',maxItems:200,items:{type:'object',description:'Saved step with caption and actions. Use [] for live teaching.'}},boardId:{type:'string',description:'Legacy board id from this chat history only.'}}),required:['title','steps']}},
  {name:'teacher_read',description:'Read before continuing or retrying. Returns nextY and the oldest waiting studentTurn. Default context is bounded.',annotations:{readOnlyHint:true},
    inputSchema:object({conversationId,turnId,detail:{enum:['focused','compact','full'],description:'Compact lists all objects. Full also includes strokes, styles and images.'}})},
  {name:'teacher_step',description:'Write notes, a graph, or drawing actions. Add a question to pause for practice. For a studentTurn use reply alone.',
    inputSchema:{...object({...step.properties,conversationId,notes:{type:'array',minItems:1,maxItems:12,items:{type:'string',maxLength:2000}},
      graph,reply:{...object({turnId,text:{type:'string',maxLength:2000}}),required:['turnId','text']}}),required:['conversationId']}},
  {name:'teacher_control',description:'Review saved writing or detach for editing.',inputSchema:{...object({conversationId,command:{enum:['play','pause','next','back','restart','detach']}}),required:['conversationId','command']}},
  {name:'teacher_snapshot',description:'Inspect layout. With turnId, get the student’s saved crop when hasCrop is true.',annotations:{readOnlyHint:true},inputSchema:{...object({conversationId,turnId}),required:['conversationId']}}
];
async function handle(message){
  if(!message||message.jsonrpc!=='2.0')return {jsonrpc:'2.0',id:message?.id??null,error:{code:-32600,message:'Invalid request'}};
  if(message.id===undefined)return null;
  const reply=result=>({jsonrpc:'2.0',id:message.id,result});
  if(message.method==='initialize'){
    clientName=String(message.params?.clientInfo?.name||'MCP client').slice(0,100);
    const version=message.params?.protocolVersion;
    return reply({protocolVersion:['2024-11-05','2025-03-26','2025-06-18'].includes(version)?version:'2025-06-18',
      capabilities:{tools:{},resources:{subscribe:true}},serverInfo:{name:'elixdraw-teacher',version:'2.1.0'},
      instructions:'Teach live. Retain the first conversationId for every call in this chat. Append new topics below earlier work with pageBreak:true. Read student turns before feedback. Write explanations once on the board. Inspect visuals when needed.'});
  }
  if(message.method==='resources/list')return reply({resources:[]});
  if(message.method==='resources/templates/list')return reply({resourceTemplates:[{name:'Lesson questions',uriTemplate:'elixdraw://lesson/{conversationId}/questions',mimeType:'application/json'}]});
  if(['resources/read','resources/subscribe','resources/unsubscribe'].includes(message.method)){
    const uri=message.params?.uri, key=[...known].find(k=>uriFor(k)===uri);
    if(!key)return {jsonrpc:'2.0',id:message.id,error:{code:-32002,message:'Use the conversationId from a lesson opened by this connection.'}};
    const subscribe=message.method==='resources/subscribe';
    try{
      if(subscribe)subscriptions.add(key);
      if(message.method==='resources/unsubscribe')subscriptions.delete(key);
      const result=await request('teacher_read',{conversationId:key},{origin:origin(key,message.method==='resources/read')});
      if(!timer&&subscriptions.size)timer=setInterval(checkNotifications,500).unref();
      if(!subscriptions.size){clearInterval(timer);timer=null;}
      if(message.method==='resources/read')return reply({contents:[{uri,mimeType:'application/json',text:JSON.stringify({pendingCount:result.pendingCount,studentTurn:result.studentTurn})}]});
      return reply({});
    }catch(e){
      if(subscribe)subscriptions.delete(key);
      return {jsonrpc:'2.0',id:message.id,error:{code:-32000,message:e.message}};
    }
  }
  if(message.method==='ping')return reply({});
  if(message.method==='tools/list')return reply({tools});
  if(message.method==='tools/call'){
    const name=message.params?.name;
    if(!tools.some(t=>t.name===name))return {jsonrpc:'2.0',id:message.id,error:{code:-32602,message:'Unknown tool'}};
    try{
      const args=message.params.arguments||{};
      if(name==='teacher_read'&&!args.conversationId)return reply({content:[{type:'text',text:JSON.stringify({needsConversation:true,instruction:'For a new chat call teacher_start with title and empty steps. Reuse the returned conversationId on EVERY subsequent tool call in this chat. For an older chat, recover its key (or legacy boardId) from its tool history. No current board was read or changed.'})}]});
      if(name!=='teacher_start'&&!args.conversationId)throw new Error('conversationId is required. Use the key returned by teacher_start in this chat.');
      const source=origin(args.conversationId,name==='teacher_read');
      source.usage=message.params._meta?.['elixdraw/usage'];
      const result=await request(name,args,{origin:source});
      if(result.conversationId)known.add(result.conversationId);
      if(result.board){
        // The workspace directory includes other conversations. Return only this board.
        delete result.board.boards;
        if(args.detail!=='full')result.board.elements=result.board.elements.map(e=>{
          const {id,type,x,y,w,h,text}=e;
          return {id,type,x,y,w,h,text};
        });
      }
      return reply({content:name==='teacher_snapshot'?[{type:'image',mimeType:'image/png',data:result.data}]:[{type:'text',text:JSON.stringify(result)}]});}
    catch(e){return reply({isError:true,content:[{type:'text',text:e.message}]});}
  }
  return {jsonrpc:'2.0',id:message.id,error:{code:-32601,message:'Method not found'}};
}
module.exports={handle,tools};
if(require.main===module){
  const lines=readline.createInterface({input:process.stdin,crlfDelay:Infinity});let queue=Promise.resolve();
  const send=value=>{if(value)process.stdout.write(JSON.stringify(value)+'\n');};
  lines.on('line',line=>{queue=queue.then(async()=>{let parsed;try{if(Buffer.byteLength(line)>2*1024*1024)throw new Error();parsed=JSON.parse(line);}catch{send({jsonrpc:'2.0',id:null,error:{code:-32700,message:'Invalid JSON or oversized message'}});return;}send(await handle(parsed));}).catch(e=>{process.stderr.write(e.message+'\n');});});
}
