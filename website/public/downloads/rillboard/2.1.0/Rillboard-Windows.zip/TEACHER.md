# Teacher board

Open **Rillboard** from the Desktop or Start menu, or run **Rillboard.exe**. Ask your connected assistant to **“use my whiteboard”**. The assistant writes and draws on the Windows whiteboard through its connected tools.

Each chat creates a separate board in the Lessons folder; new topics in that chat continue on the same scrolling board. Previous boards remain in My boards. Drawings, editable ids, lesson steps and playback position save on this computer and survive closing the app. Choose a drawing tool to annotate the board. **Teaching → Pause teacher writing** pauses incoming changes. The panel shows the client that last worked on this lesson.

The lesson is a **continuous scrolling board**. New sections go below the previous writing. Scroll with the mouse wheel, drag the canvas, use Page Up / Page Down, or use **Earlier / Later / Latest writing**. The vertical scrollbar lets you return to any section. Writing stays at a readable scale instead of shrinking the whole lesson onto one screen. Open **Teaching → Review lesson** to revisit steps without removing already revealed work. Old slide-style bulk clears are converted into new sections; individual corrections can still remove an element. Existing unchanged lesson timelines are upgraded automatically with a local recovery copy.

**Lesson files → Save lesson** exports a replayable JSON backup; **Open lesson** loads one. A drawing-only `.excalidraw` export preserves editable elements but does not carry the lesson timeline. Read aloud uses Windows speech synthesis.

## Connect the assistant

Open the three-dot menu → **Settings**, then choose **Add teaching** under **Add-ons**. **Set up** shows the installed connector path and setup for any local MCP client, with presets for Codex, Gemini CLI, and Claude Desktop. Removing the plugin stops the local bridge. Saved lessons stay in My boards.

This local MCP server lets the assistant in a supported desktop chat control your actual whiteboard. No separate model or OpenAI API key is needed. Node.js 18 or newer is required for the connector; the standalone drawing app does not need Node.

Run **Connect Teacher.cmd** or register from PowerShell using the connector path shown in Settings.

```powershell
codex mcp add elixdraw-teacher -- node "$env:LOCALAPPDATA\Programs\CraftSketchDesktop\teacher-bridge\server.cjs"
```

Restart the MCP connection or start a new chat if the current chat already loaded its tools. Ask: **“Use elixdraw-teacher to teach me fractions on the board, one step at a time.”**

Tools: `teacher_read`, `teacher_start`, `teacher_step`, `teacher_control`, `teacher_snapshot`. A tool call opens the Windows app if needed. Snapshot returns an actual PNG of the whiteboard and captions.

## Direct access from the command line

From the app directory, pass a JSON file to each command. Start with a new conversation key in `lesson.json` and use the same key in each subsequent request. The other files can add fields for the step or playback command.

```powershell
node .\teacher-bridge\client.cjs teacher_start lesson.json
node .\teacher-bridge\client.cjs teacher_read conversation.json
node .\teacher-bridge\client.cjs teacher_step step.json
node .\teacher-bridge\client.cjs teacher_control control.json
node .\teacher-bridge\client.cjs teacher_snapshot conversation.json board.png
```

Example lesson:

```json
{
  "conversationId": "65760716-6357-4501-ab5b-e8bb82a20508",
  "title": "Understanding force",
  "steps": [{
    "caption": "A force can push an object. The arrow shows its direction.",
    "durationMs": 6000,
    "actions": [
      {"op":"add","element":{"id":"block","type":"rectangle","x":150,"y":200,"w":180,"h":120,"fill":"#a5d8ff","fillStyle":"solid"}},
      {"op":"add","element":{"id":"force","type":"arrow","x":350,"y":260,"w":180,"h":0,"stroke":"#e03131","strokeWidth":3}},
      {"op":"add","element":{"id":"label","type":"text","x":390,"y":210,"text":"Force","fontSize":28,"stroke":"#e03131"}}
    ],
    "focus": ["force"]
  }]
}
```

For live teaching start `{"title":"Understanding force","steps":[]}`, retain the returned `conversationId`, and include it in every subsequent tool call. Continue with `teacher_step`. Actions add, update (`{"op":"update","id":"label","changes":{"text":"F = ma"}}`) or remove individual errors. IDs use letters, digits, underscores and hyphens. A step can specify `pointer: {x,y}`. Use the returned writingWidth for horizontal coordinates and extend y downward. For text, send teacher_step with conversationId and notes (an array of short text blocks). The app wraps and lays them out across the available width. Settings offers quick reveal or instant writing. To inspect precise styles, pen points or images, request teacher_read with detail set to full. **Read `teacher_read.nextY` before adding a new section, or set `pageBreak:true` and draw the new section using local y coordinates. Never clear old pages or start another board just to make room.** Inspect screenshots for readability. Continue the same topic with `teacher_step`.

`teacher_control` takes `{"command":"next"}` or `play`, `pause`, `back`, `restart`, `detach`. Full lessons start paused; live steps appear immediately. Paths draw progressively and text writes character by character. Unicode equations, shapes, freehand paths and embedded images are supported. Text uses a handwriting-style font; arbitrary LaTeX and natural pen stroke synthesis are not implemented. This connection supplies drawing tools to the current chat model, so the connected chat app chooses the model.

## Implementation and tests

The native host polls `%LOCALAPPDATA%\CraftSketchDesktop\TeacherBridge`. Requests and replies are atomic, size bounded, tied to one process session, and expire. No network port, public tunnel or API credential is used. Only documented teacher commands run; there is no general-purpose script-execution tool. The bridge trusts processes running as your Windows user. After a timeout, read the board before retrying a mutation because it might already have been applied.

`TEACHER_BRIDGE_DIR` overrides the IPC folder for tests. Use `Rillboard.exe --data-dir <absolute-directory>` for an isolated profile.

Verification: `npm.cmd test`, `npm.cmd run build`, `node qa/teacher-review.cjs`, `npm.cmd run verify:desktop`. Teacher review tests actual MCP stdio calls, native playback, invalid updates, persistence and screenshot capture. Reports are under `qa/teacher-check/`.

## Chat ownership and interactive practice

Rillboard is an independent drawing app. **Teaching** is an optional overlay, closed by default. **Style** opens the drawing properties only when you want them. Neither panel reserves canvas space. Explanation and practice share a collapsible classroom card. **Lesson** restores it. The window title and shortcut describe a whiteboard, not a built-in chatbot.

One conversation owns one locally saved board. This connector does not assume an MCP process or the foreground board identifies a conversation. It uses an explicit stable `conversationId` on every call:

1. In a new chat, call `teacher_start` with a title and `steps:[]`. Retain the returned `conversationId` in that chat's tool history. You may instead supply a stable chat identifier or a newly generated UUID on this first call, which also makes retries idempotent.
2. Include that key on every `teacher_read`, `teacher_step`, `teacher_control` and `teacher_snapshot`. A different chat must use a different key.
3. When resuming, recover the key from this chat history and call `teacher_read`. It opens the linked board, even if another board is currently visible. `teacher_start` with an existing key resumes without overwriting its lesson.
4. A new topic in the same chat is a new section (`pageBreak:true`), not another project. Never erase older pages to make room.
5. Older lessons are preserved. To link one for the first time, use `teacher_start` with its `boardId` from the old chat's tool history and a stable `conversationId`. If that identity is unavailable, ask which old lesson to use; never guess from the current board.

MCP calls without a key cannot modify an arbitrary open board. An unscoped `teacher_read` returns setup guidance only. The direct local CLI retains unscoped access for inspecting the app, but assistants must pass chat keys there too. New chats do not receive existing chat keys from unscoped MCP reads. If a chat has loaded the older tool schemas, refresh elixdraw-teacher in the connected client once; the CLI already accepts the new parameters.

## Classroom questions and focused context

**Ask teacher** opens a question beside the board. Students can select or lasso objects first, or use **Point on board** to mark one location in a graph. An explicit submission freezes the selected marks and nearby labels. When the selection includes handwriting or an image, the app saves a local PNG up to 640 × 480. **Draw it** accepts a drawn practice answer. Drafts stay on the device. Submitted questions survive board switches, restarts, and add-on removal.

On its next turn the teacher calls `teacher_read({conversationId})`. The oldest waiting question appears as `studentTurn` with its id, text, prompt, and selection. Read a specific question with `turnId`. A question with `hasCrop:true` supports `teacher_snapshot({conversationId,turnId})`. For feedback, call `teacher_step({conversationId,reply:{turnId,text}})`. Elixdraw places the answer near the mark when space permits. On a crowded board, **Show original mark** returns to the referenced location. Retrying the same reply leaves one answer on the board.

Regular reads return at most eight recent objects when there is no submission. For a waiting question, they include its frozen reference. A step returns a short receipt. Request `detail:"compact"` explicitly for a full object inventory, or `detail:"full"` for styles, images, and strokes. `notes` lays out text locally. For a graph, use `graph:{expression:"sin(x)",xmin:0,xmax:6,ymin:-2,ymax:2,step:1,xLabel:"Time",yLabel:"Displacement"}`. Equations separated by newlines share axes. `highlight` emphasizes a curve by zero-based index. Scrolling, review, and individual pen strokes use no model calls.

**Teaching → Lesson usage** shows local connector requests, structured request and response bytes, and image requests. Screenshot bytes and protocol envelopes are excluded. A host with model usage data can attach `_meta["elixdraw/usage"] = {id,input,cachedInput,output}` to a later `tools/call` for the same lesson. Use a stable id per model turn and include cached input within the input total. Repeating an id updates its counters once. Otherwise model tokens are shown as unavailable. Byte counts measure transport overhead and cannot establish a provider’s bill.

The connector advertises MCP resource subscriptions. After opening a lesson, a host may subscribe to `elixdraw://lesson/{conversationId}/questions` (percent-encode the key). Explicit submission sends a `notifications/resources/updated` notification to the subscribed client for that lesson. The host can start a turn in the owning conversation and read the pending question. The app also supports tool-only clients through **Copy chat prompt**. Bringing a window to the foreground does not submit a question.

Native verification for these changes: `npm.cmd test`, `npm.cmd run build`, `npm.cmd run verify:teacher`, `npm.cmd run verify:bridge`, and `npm.cmd run verify:desktop`. The conversation checks use isolated profiles and preserve real user boards.
